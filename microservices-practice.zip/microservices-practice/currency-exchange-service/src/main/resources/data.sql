insert into currency_exchange_rates (currency_from, currency_to, conversion_rate) values ('usd', 'inr', 80.00);
insert into currency_exchange_rates (currency_from, currency_to, conversion_rate) values ('eur', 'inr', 100.00);
insert into currency_exchange_rates (currency_from, currency_to, conversion_rate) values ('aud', 'inr', 70.00);