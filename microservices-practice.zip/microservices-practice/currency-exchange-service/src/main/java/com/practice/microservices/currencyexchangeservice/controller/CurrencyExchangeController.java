package com.practice.microservices.currencyexchangeservice.controller;

import com.practice.microservices.currencyexchangeservice.beans.CurrencyExchangeRates;
import com.practice.microservices.currencyexchangeservice.repository.CurrencyExchangeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class CurrencyExchangeController {

    final CurrencyExchangeRepository currencyExchangeRepository;

    CurrencyExchangeController(@Autowired CurrencyExchangeRepository currencyExchangeRepository) {
        this.currencyExchangeRepository = currencyExchangeRepository;
    }

    @GetMapping("/exchange/from/{from}/to/{to}")
    public ResponseEntity<CurrencyExchangeRates> getCurrencyExchangeRate(@PathVariable String from,
                                                                          @PathVariable String to) {
        return ResponseEntity.ok()
                .body(currencyExchangeRepository.findAll()
                        .stream()
                        .filter(currencyExchangeRate -> currencyExchangeRate.getFrom().equals(from) && currencyExchangeRate.getTo().equals(to))
                        .findAny().orElseThrow(RuntimeException::new));
    }

    @GetMapping("/exchange/findAll")
    public ResponseEntity<List<CurrencyExchangeRates>> getAllCurrencyExchangeRates() {

        return ResponseEntity.ok()
                .body(currencyExchangeRepository.findAll());
    }
}
