package com.practice.microservices.currencyexchangeservice.repository;

import com.practice.microservices.currencyexchangeservice.beans.CurrencyExchangeRates;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CurrencyExchangeRepository extends JpaRepository<CurrencyExchangeRates, Long> {
}
