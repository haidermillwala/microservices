package com.practice.microservices.currencyconversionservice.controller;

import com.practice.microservices.currencyconversionservice.beans.CurrencyConversion;
import com.practice.microservices.currencyconversionservice.proxy.CurrencyExchangeProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@RestController
public class CurrencyConversionController {

    final CurrencyExchangeProxy currencyExchangeProxy;

    CurrencyConversionController(@Autowired CurrencyExchangeProxy currencyExchangeProxy) {
        this.currencyExchangeProxy = currencyExchangeProxy;
    }

    @GetMapping("/calculate/from/{from}/to/{to}/{quantity}")
    public ResponseEntity<CurrencyConversion> calcuateConvertedCurrency(@PathVariable String from,
                                                                        @PathVariable String to,
                                                                        @PathVariable BigDecimal quantity) {
        CurrencyConversion currencyExchangeRate = currencyExchangeProxy.getCurrencyExchangeRate(from, to).getBody();

        return ResponseEntity.ok()
                .body(CurrencyConversion.builder()
                        .from(from)
                        .to(to)
                        .conversionRate(BigDecimal.ONE)
                        .quantity(quantity)
                        .convertedCurrencyValue(quantity.multiply(BigDecimal.ONE))
                        .build());
    }
}
