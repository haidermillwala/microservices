package com.practice.microservices.currencyconversionservice.proxy;

import com.practice.microservices.currencyconversionservice.beans.CurrencyConversion;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="currency-exchange-service", url="http://localhost:8001")
public interface CurrencyExchangeProxy {

    @GetMapping("/exchange/from/{from}/to/{to}")
    public ResponseEntity<CurrencyConversion> getCurrencyExchangeRate(@PathVariable String from,
                                                                     @PathVariable String to);
}


